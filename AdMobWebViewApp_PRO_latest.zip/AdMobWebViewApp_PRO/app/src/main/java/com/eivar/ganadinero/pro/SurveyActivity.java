package com.eivar.ganadinero.pro;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class SurveyActivity extends AppCompatActivity {

    private static final String PREFS = "app_prefs";
    private static final String KEY_BALANCE = "balance_usd";
    private static final String INTERSTITIAL_ID = "ca-app-pub-3127387243652988/7997268226";
    private static final double SURVEY_REWARD = 2.00;

    private InterstitialAd interstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey);

        MobileAds.initialize(this, initializationStatus -> {});
        preloadInterstitial();

        Button submit = findViewById(R.id.btnSubmitSurvey);
        submit.setOnClickListener(v -> {
            addBalance(SURVEY_REWARD);
            Toast.makeText(this, "¡Felicidades! Ganaste $2.00", Toast.LENGTH_LONG).show();
            showInterstitial();
            finish();
        });
    }

    private void addBalance(double usd) {
        SharedPreferences sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        double cur = Double.longBitsToDouble(sp.getLong(KEY_BALANCE, Double.doubleToLongBits(0)));
        cur += usd;
        sp.edit().putLong(KEY_BALANCE, Double.doubleToLongBits(cur)).apply();
    }

    private void preloadInterstitial() {
        AdRequest req = new AdRequest.Builder().build();
        InterstitialAd.load(this, INTERSTITIAL_ID, req, new InterstitialAdLoadCallback() {
            @Override public void onAdLoaded(@NonNull InterstitialAd ad) { interstitialAd = ad; }
            @Override public void onAdFailedToLoad(@NonNull LoadAdError error) { interstitialAd = null; }
        });
    }

    private void showInterstitial() {
        if (interstitialAd != null) {
            interstitialAd.show(this);
            interstitialAd = null;
        }
    }
}