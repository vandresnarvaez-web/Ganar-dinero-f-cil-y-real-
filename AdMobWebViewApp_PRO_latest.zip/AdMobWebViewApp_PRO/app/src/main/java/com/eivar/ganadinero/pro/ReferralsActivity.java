package com.eivar.ganadinero.pro;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.UUID;

public class ReferralsActivity extends AppCompatActivity {

    private static final String PREFS = "app_prefs";
    private static final String KEY_BALANCE = "balance_usd";
    private static final String KEY_MY_CODE = "my_code";
    private static final String KEY_BONUS_CLAIMED = "bonus_claimed";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_referrals);

        SharedPreferences sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String code = sp.getString(KEY_MY_CODE, null);
        if (code == null) {
            code = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
            sp.edit().putString(KEY_MY_CODE, code).apply();
        }

        TextView tvMy = findViewById(R.id.tvMyCode);
        tvMy.setText("Tu código: " + code);

        EditText etFriend = findViewById(R.id.etFriendCode);
        Button btnClaim = findViewById(R.id.btnClaimBonus);
        btnClaim.setOnClickListener(v -> {
            boolean claimed = sp.getBoolean(KEY_BONUS_CLAIMED, false);
            if (claimed) {
                Toast.makeText(this, "Ya reclamaste tu bono", Toast.LENGTH_SHORT).show();
                return;
            }
            String friend = etFriend.getText().toString().trim();
            if (friend.length() < 4) {
                Toast.makeText(this, "Código inválido", Toast.LENGTH_SHORT).show();
                return;
            }
            addBalance(1.00);
            sp.edit().putBoolean(KEY_BONUS_CLAIMED, true).apply();
            Toast.makeText(this, "¡Bono de $1.00 aplicado!", Toast.LENGTH_LONG).show();
        });
    }

    private void addBalance(double usd) {
        SharedPreferences sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        double cur = Double.longBitsToDouble(sp.getLong(KEY_BALANCE, Double.doubleToLongBits(0)));
        cur += usd;
        sp.edit().putLong(KEY_BALANCE, Double.doubleToLongBits(cur)).apply();
    }
}