package com.eivar.ganadinero.pro;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS = "app_prefs";
    private static final String KEY_BALANCE = "balance_usd";

    private static final String PUBLIC_URL = "https://ganardineroreal.on.websim.com/#login?ref=VAND703";

    private static final String INTERSTITIAL_ID = "ca-app-pub-3127387243652988/7997268226";
    private static final String REWARDED_ID = "ca-app-pub-3127387243652988/2086465993";

    private static final double REWARDED_AMOUNT = 0.75;
    private static final long INTERSTITIAL_COOLDOWN_MS = 120_000;
    private static final long FIRST_INTERSTITIAL_DELAY = 10_000;
    private static final int ACTIONS_FOR_INTERSTITIAL = 3;

    private WebView webView;
    private AdView banner;
    private InterstitialAd interstitialAd;
    private RewardedAd rewardedAd;
    private long lastInterstitialShownAt = 0;
    private int userActions = 0;

    private TextView tvBalance;
    private Button btnReward, btnSurvey, btnReferrals;

    private final Handler handler = new Handler();

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvBalance = findViewById(R.id.tvBalance);
        btnReward = findViewById(R.id.btnReward);
        btnSurvey = findViewById(R.id.btnSurvey);
        btnReferrals = findViewById(R.id.btnReferrals);

        MobileAds.initialize(this, initializationStatus -> {});

        webView = findViewById(R.id.webview);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl(PUBLIC_URL);

        banner = findViewById(R.id.adView);
        banner.loadAd(new AdRequest.Builder().build());
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                banner.loadAd(new AdRequest.Builder().build());
                handler.postDelayed(this, 60_000);
            }
        }, 60_000);

        btnReward.setOnClickListener(v -> showRewarded());
        preloadRewarded();

        btnSurvey.setOnClickListener(v -> startActivity(new Intent(this, SurveyActivity.class)));
        btnReferrals.setOnClickListener(v -> startActivity(new Intent(this, ReferralsActivity.class)));

        handler.postDelayed(this::showInterstitial, FIRST_INTERSTITIAL_DELAY);

        webView.setOnScrollChangeListener((v, sx, sy, ox, oy) -> onUserAction());
        webView.setOnTouchListener((v, e) -> { onUserAction(); return false; });

        updateBalanceLabel();
    }

    private void onUserAction() {
        userActions++;
        long now = System.currentTimeMillis();
        if (userActions % ACTIONS_FOR_INTERSTITIAL == 0 && (now - lastInterstitialShownAt) >= INTERSTITIAL_COOLDOWN_MS) {
            showInterstitial();
        }
    }

    private void preloadInterstitial() {
        AdRequest request = new AdRequest.Builder().build();
        InterstitialAd.load(this, INTERSTITIAL_ID, request, new InterstitialAdLoadCallback() {
            @Override public void onAdLoaded(@NonNull InterstitialAd ad) { interstitialAd = ad; }
            @Override public void onAdFailedToLoad(@NonNull LoadAdError error) { interstitialAd = null; }
        });
    }

    private void showInterstitial() {
        if (interstitialAd == null) preloadInterstitial();
        if (interstitialAd != null) {
            interstitialAd.show(this);
            interstitialAd = null;
            lastInterstitialShownAt = System.currentTimeMillis();
            preloadInterstitial();
        }
    }

    private void preloadRewarded() {
        AdRequest request = new AdRequest.Builder().build();
        RewardedAd.load(this, REWARDED_ID, request, new RewardedAdLoadCallback() {
            @Override public void onAdLoaded(@NonNull RewardedAd ad) { rewardedAd = ad; }
            @Override public void onAdFailedToLoad(@NonNull LoadAdError error) { rewardedAd = null; }
        });
    }

    private void showRewarded() {
        if (rewardedAd != null) {
            rewardedAd.show(this, rewardItem -> {
                addBalance(REWARDED_AMOUNT);
                Toast.makeText(this, "¡Ganaste $"+String.format("%.2f", REWARDED_AMOUNT)+"!", Toast.LENGTH_SHORT).show();
                preloadRewarded();
            });
            rewardedAd = null;
        } else {
            Toast.makeText(this, "Cargando anuncio… intenta nuevamente", Toast.LENGTH_SHORT).show();
            preloadRewarded();
        }
    }

    private void addBalance(double usd) {
        SharedPreferences sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        double cur = Double.longBitsToDouble(sp.getLong(KEY_BALANCE, Double.doubleToLongBits(0)));
        cur += usd;
        sp.edit().putLong(KEY_BALANCE, Double.doubleToLongBits(cur)).apply();
        updateBalanceLabel();
    }

    private void updateBalanceLabel() {
        SharedPreferences sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        double cur = Double.longBitsToDouble(sp.getLong(KEY_BALANCE, Double.doubleToLongBits(0)));
        tvBalance.setText("Saldo: $" + String.format("%.2f", cur));
    }

    @Override protected void onPause() { if (banner != null) banner.pause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (banner != null) banner.resume(); }
    @Override protected void onDestroy() { if (banner != null) banner.destroy(); super.onDestroy(); }
}